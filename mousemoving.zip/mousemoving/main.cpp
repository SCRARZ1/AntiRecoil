// Complete example based on Dear ImGui example_win32_directx11
#include <Windows.h>
#include <d3d11.h>
#include <random>
#include <fstream>
#include <string>
#include <filesystem>
#include "imgui.h"
#include "backends/imgui_impl_win32.h"
#include "backends/imgui_impl_dx11.h"

#pragma comment(lib,"d3d11.lib")
#pragma comment(lib,"dxgi.lib")
#pragma comment(lib,"d3dcompiler.lib")

namespace fs = std::filesystem;

static ID3D11Device* g_pd3dDevice=nullptr;
static ID3D11DeviceContext* g_pd3dDeviceContext=nullptr;
static IDXGISwapChain* g_pSwapChain=nullptr;
static ID3D11RenderTargetView* g_mainRenderTargetView=nullptr;

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);

void CreateRenderTarget(){ID3D11Texture2D* b=nullptr;g_pSwapChain->GetBuffer(0,IID_PPV_ARGS(&b));g_pd3dDevice->CreateRenderTargetView(b,nullptr,&g_mainRenderTargetView);b->Release();}
void CleanupRenderTarget(){if(g_mainRenderTargetView){g_mainRenderTargetView->Release();g_mainRenderTargetView=nullptr;}}
void CleanupDevice(){CleanupRenderTarget(); if(g_pSwapChain)g_pSwapChain->Release(); if(g_pd3dDeviceContext)g_pd3dDeviceContext->Release(); if(g_pd3dDevice)g_pd3dDevice->Release();}

LRESULT WINAPI WndProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam){
    if(ImGui_ImplWin32_WndProcHandler(hWnd,msg,wParam,lParam)) return 1;
    switch(msg){
        case WM_SIZE:
            if(g_pd3dDevice&&wParam!=SIZE_MINIMIZED){CleanupRenderTarget();g_pSwapChain->ResizeBuffers(0,LOWORD(lParam),HIWORD(lParam),DXGI_FORMAT_UNKNOWN,0);CreateRenderTarget();}
            return 0;
        case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProc(hWnd,msg,wParam,lParam);
}

// Helper function to get the current executable directory
fs::path GetExeDirectory() {
    wchar_t buffer[MAX_PATH];
    GetModuleFileNameW(NULL, buffer, MAX_PATH);
    return fs::path(buffer).parent_path();
}

// Preset Saving Functions
void SavePreset(const std::string& presetName, float moveX, float moveY, int intervalMs, bool jitterEnabled, int jitterEveryTicks) {
    fs::path presetDir = GetExeDirectory() / "presets";
    
    // Create presets directory if it doesn't exist
    if (!fs::exists(presetDir)) {
        fs::create_directories(presetDir);
    }
    
    fs::path filepath = presetDir / (presetName + ".cfg");
    std::ofstream out(filepath);
    if (out.is_open()) {
        out << moveX << "\n";
        out << moveY << "\n";
        out << intervalMs << "\n";
        out << jitterEnabled << "\n";
        out << jitterEveryTicks << "\n";
    }
}

bool LoadPreset(const std::string& presetName, float& moveX, float& moveY, int& intervalMs, bool& jitterEnabled, int& jitterEveryTicks) {
    fs::path filepath = GetExeDirectory() / "presets" / (presetName + ".cfg");
    std::ifstream in(filepath);
    if (in.is_open()) {
        in >> moveX;
        in >> moveY;
        in >> intervalMs;
        in >> jitterEnabled;
        in >> jitterEveryTicks;
        return true;
    }
    return false;
}

int WINAPI wWinMain(HINSTANCE hInst,HINSTANCE, PWSTR,int){
    WNDCLASSEX wc={sizeof(wc),CS_CLASSDC,WndProc,0,0,hInst,nullptr,nullptr,nullptr,nullptr,L"MouseMover",nullptr};
    RegisterClassEx(&wc);
    HWND hwnd=CreateWindow(wc.lpszClassName,L"Mouse Mover",WS_OVERLAPPEDWINDOW,100,100,420,400,nullptr,nullptr,hInst,nullptr);

    DXGI_SWAP_CHAIN_DESC sd={};
    sd.BufferCount=2;
    sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow=hwnd;
    sd.SampleDesc.Count=1;
    sd.Windowed=TRUE;
    sd.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;

    D3D_FEATURE_LEVEL fl;
    D3D_FEATURE_LEVEL levels[]={D3D_FEATURE_LEVEL_11_0};
    if(D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,levels,1,D3D11_SDK_VERSION,&sd,&g_pSwapChain,&g_pd3dDevice,&fl,&g_pd3dDeviceContext)!=S_OK)
        return 1;

    CreateRenderTarget();
    ShowWindow(hwnd,SW_SHOWDEFAULT);
    UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice,g_pd3dDeviceContext);

    float moveX = 1.0f;
    float moveY = 0.0f;
    int   intervalMs = 16;
    bool  jitterEnabled = false;
    int   jitterEveryTicks = 5;   // apply offset every N ticks
    int   tickCount = 0;
    float currentOffsetX = 0.0f;
    float currentOffsetY = 0.0f;
    bool  done = false;
    DWORD lastMoveTime = 0;

    // Preset variables
    char presetBuffer[64] = "default";

    // Try loading "default" preset at startup if it exists
    LoadPreset("default", moveX, moveY, intervalMs, jitterEnabled, jitterEveryTicks);

    // Random number setup
    std::mt19937 rng((unsigned)GetTickCount());
    std::uniform_real_distribution<float> jitterDist(-0.5f, 0.5f);

    while(!done){
        MSG msg;
        while(PeekMessage(&msg,nullptr,0,0,PM_REMOVE)){
            TranslateMessage(&msg);
            DispatchMessage(&msg);
            if(msg.message==WM_QUIT) done=true;
        }

        // Move only when Caps Lock is ON and BOTH mouse buttons are held
        DWORD now = GetTickCount();
        if((GetKeyState(VK_CAPITAL) & 0x0001) &&
           (GetAsyncKeyState(VK_LBUTTON) & 0x8000) &&
           (GetAsyncKeyState(VK_RBUTTON) & 0x8000) &&
           (now - lastMoveTime >= (DWORD)intervalMs)){

            // Refresh jitter offset every N ticks
            if(jitterEnabled){
                tickCount++;
                if(tickCount >= jitterEveryTicks){
                    currentOffsetX = jitterDist(rng);
                    currentOffsetY = jitterDist(rng);
                    tickCount = 0;
                }
            } else {
                currentOffsetX = 0.0f;
                currentOffsetY = 0.0f;
                tickCount = 0;
            }

            INPUT input = {0};
            input.type = INPUT_MOUSE;
            input.mi.dx = (LONG)(moveX + currentOffsetX);
            input.mi.dy = (LONG)(moveY + currentOffsetY);
            input.mi.dwFlags = MOUSEEVENTF_MOVE;

            SendInput(1, &input, sizeof(INPUT));
            lastMoveTime = now;
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        ImGui::Begin("Mouse Mover");
        bool capsOn = (GetKeyState(VK_CAPITAL) & 0x0001) != 0;
        ImGui::Text("Caps Lock: %s", capsOn ? "ON (active)" : "OFF (disabled)");
        ImGui::Text("Hold BOTH mouse buttons to move");
        ImGui::Separator();
        ImGui::InputFloat("X  (+right / -left)", &moveX, 1.0f, 5.0f, "%.1f");
        ImGui::InputFloat("Y  (+down  / -up)",   &moveY, 1.0f, 5.0f, "%.1f");
        ImGui::SliderInt("Interval (ms)", &intervalMs, 1, 100);
        ImGui::Separator();
        ImGui::Checkbox("Jitter Offset", &jitterEnabled);
        if(jitterEnabled){
            ImGui::SliderInt("Jitter Every N Ticks", &jitterEveryTicks, 1, 20);
            ImGui::Text("Current offset: (%.2f, %.2f)", currentOffsetX, currentOffsetY);
        }
        
        // --- PRESET SYSTEM UI ---
        ImGui::Separator();
        ImGui::Text("Presets Management");
        ImGui::InputText("Preset Name", presetBuffer, IM_ARRAYSIZE(presetBuffer));
        
        if (ImGui::Button("Save Preset")) {
            SavePreset(presetBuffer, moveX, moveY, intervalMs, jitterEnabled, jitterEveryTicks);
        }
        ImGui::SameLine();
        if (ImGui::Button("Load Preset")) {
            LoadPreset(presetBuffer, moveX, moveY, intervalMs, jitterEnabled, jitterEveryTicks);
        }
        // -------------------------

        ImGui::End();

        ImGui::Render();
        float clr[4]={0.1f,0.1f,0.1f,1.0f};
        g_pd3dDeviceContext->OMSetRenderTargets(1,&g_mainRenderTargetView,nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView,clr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1,0);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    CleanupDevice();
    DestroyWindow(hwnd);
    UnregisterClass(wc.lpszClassName,hInst);
    return 0;
}